/*---------------------------------------------
2019/9/8 記入 endo daisuke
Thresholdクラスの定義. neuronクラスが１つづつ必ず持つインスタンス
電位の単位はmV.時間はmsec
定数:
- 最低閾値: omega (excitaotry, inhibitoryで変わる)
- 時間変化の数: N (基本的に2.おそらく変えることはない)
- 時間変化のサイズ: *alpha (１次元ベクトル)
- 時間変化の時定数: tau[] (１次元ベクトル.おそらく変えることはない)
変数:
- それぞれの時間変化の値: *u (１次元ベクトル)
- 閾値の値: theta
関数:（特殊なものだけ)
- 時刻を(dtだけ)進める関数: update
- spikeした時に閾値をあげる関数: increase_theta
---------------------------------------------*/
#ifndef THRESHOLD_H
#define THRESHOLD_H

class Threshold{
	static const int N; // MATモデルの時間変化の数. 基本的に2.
	double theta;
	double *u;
	double omega;
	double *alpha;
	static const double tau[];
public:
	Threshold();
	virtual void init_pointer(); //ポインタ変数の初期化
	// virtula set_N(int argN); constで定義していて高速化を図る
	// virtula set_tau(int i, double tau_i);
	virtual void set_omega(double omega);
	/*閾値の最小ラインを決める値 omega*/
	virtual void set_alpha(int i, double alpha_i);
	virtual double get_theta();
	virtual double get_omega();
	virtual void increase_theta();// spikeした時
	virtual void update();
	virtual ~Threshold(){};
};

#endif
