#ifndef HYPERPARAMETER_H
#define HYPERPARAMETER_H

// simulationの時間刻み幅 (ms)
const double dt = 0.1;

/* 膜電位に入れる定常電流.
基本的には必要としないが, backgroundの調整に難があれば
これを入れて全体の膜電位を引き上げたり下げたりできる.
別ファイルからいじる可能性があるので、static constではない */
const double Constant_Current = 0.0;

/*
コンダクタンスと膜電位の変換公式
excitatory neuron -> excitatory neuron
excitatory neuron -> inhibitory neuron
inhibitory neuron -> excitatory neuron
inhibitory neuron -> inhibitory neuron
で値が少し異なるので注意.
*/
const double Ge2EPSP = 26;
const double Ge_mu = -5.543;
const double Ge_sigma = 1.3;
const double Gi_mu = 0.0217;
const double Gi_sigma = 0.0171;
// 便利な関数. 行列を定義する時に便利.
double **d2array(int row, int column);
void d2free(double **array);
int **i2array(int row, int column);
void i2free(int **array);

#endif
