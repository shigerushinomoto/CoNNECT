#include<iostream>
#include<cmath>
#include<omp.h>
#include<SFMT.h>
#include<macro.h>
#include<random.h>
#include<conductance.h>
#include<neuron.h>
#include<network.h>
#include<log.h>

void Log :: init(){
  fp_g = NULL;
	Lv = new double[N];
	rate = new double[N];
	spike_num = new int[N];
	tpre = new double[N];
	tpost = new double[N];
	Interval_pre = new double[N];
	Interval_post = new double[N];
	for(int i=0; i<N; i++){
		Lv[i] = 0;
		rate[i] = 0;
		spike_num[i] = 0;
		tpre[i] = 0;
		tpost[i] = 0;
		Interval_pre[i] = 0;
		Interval_post[i] = 0;
	}
}

void Log :: fileopen(std::string spikefile, std::string Lvfile, std::string fratefile, std::string pspfile, std::string delayfile){
	/*-----------------------------------------------
	ファイル名を指定する
	spike fileを開く
	--------------------------------------------------*/
	// sustitute
	this->spikefile = spikefile;
	this->Lvfile = Lvfile;
	this->fratefile = fratefile;
	this->pspfile = pspfile;
	this->delayfile = delayfile;

	// log
	std::cout << "\t" << spikefile << " にspikeを記録していく" << std::endl;
	std::cout << "\t" << Lvfile << " にLvを記録していく" << std::endl;
	std::cout << "\t" << fratefile << " にfirig rateを記録していく" << std::endl;
	std::cout << "\t" << pspfile << " に結合行列をコンダクタンスGで記録していく. G[i][j]でjからiへの結合を表す" << std::endl;
	std::cout << "\t" << delayfile << " にdelayをmsで記録していく. delay[i][j]でjからiへの結合を表す" << std::endl;

	// open file pointer
	std::cout << "Open file " << spikefile << std::endl;
	fp_spike = fopen(spikefile.c_str(), "w");
}
void Log :: open_g(){
	/*-------------------------------------------------
	普通は使わない関数.
	平均コンダクタンスの時間変化を知りたいときに使う.
	excitatory neuronsのグループとinhibitory neuronsのグループで計算する
	----------------------------------------------------*/
	fp_g = fopen("Conductance_log.txt", "w");
}

void Log :: set_size(int N, int N_e){
	std::cout << "settting size in Log" << std::endl;
	this->N = N;
	this->N_e = N_e;
	this->N_i = N-N_e;
}

void Log :: set_time(double total_time, double reject_time){
	std::cout << "Setting total_time, reject_time in Log" << std::endl;
	std::cout << "\ttotal_time = " << total_time << "ms" << std::endl;
	std::cout << "\treject_time = " << reject_time << "ms" << std::endl;

	this->total_time = total_time;
	this->reject_time = reject_time;

	//--logを出力するときの間隔 10回だけ出力する
	std::cout << "\tRunningの最中に10回だけログを出力する" << std::endl;
	this->bin = (int)(total_time/(10.0*dt));
	this->init();
	std::cout << "\tEND: Initialized Log" << std::endl;
}
void Log :: writeConnect(double** connection){
	/*---------------------------------------------------
	excitatory neruonからの結合はplus,
	inhibitory neruonからの結合はminus
	になるように出力する
	---------------------------------------------------*/
	if(connection==NULL){
		std::cout << "Error in writeConnect: connection is NULL.";
		std::exit(1);
	}
	if(this->N==0){
		std::cout << "Error writeConnect: You must set network size N" << std::endl;
		std::exit(1);
	}

	// open file pointer
	std::cout << "Open file " << pspfile << " and Writing PSP Connection" << std::endl;
	FILE* fp_psp = fopen(pspfile.c_str(), "w");

	// write
	int i, j, N, N_e;
	N = this->N;
	N_e = this->N_e;
	for(i=0; i<N; i++){
		for(j=0; j<N_e; j++){
			fprintf(fp_psp, "%lf,", connection[i][j]);
		}
		for(j=N_e; j<N-1; j++){
			fprintf(fp_psp, "%lf,", -connection[i][j]);
		}
		fprintf(fp_psp, "%lf\n", -connection[i][N-1]);
	}

	if(fp_psp!=NULL)fclose(fp_psp);
	std::cout << "Wrote PSP connection and Closed PSP file" << std::endl;
}
void Log :: writeDelay(int** delay_step){
	/*---------------------------------------------------
	delayはプログラム上はstep幅になっている
	---------------------------------------------------*/
	if(delay_step==NULL){
		std::cout << "Error in writeDelay: Delay connection is NULL.";
		std::exit(1);
	}
	if(this->N==0){
		std::cout << "Error in writeDelay: You must set network size N" << std::endl;
		std::exit(1);
	}

	// open file pointer
	std::cout << "Open file " << delayfile << " and Writing Delay Connection" << std::endl;
	FILE *fp_delay = fopen(delayfile.c_str(), "w");

	int i, j, N, N_e;
	N = this->N;
	N_e = this->N_e;
	for(i=0; i<N; i++){
		for(j=0; j<N-1; j++){
			fprintf(fp_delay, "%lf,", delay_step[i][j]*dt);
		}
		fprintf(fp_delay, "%lf\n", delay_step[i][N-1]*dt);
	}

	if(fp_delay!=NULL)fclose(fp_delay);
	std::cout << "Wrote Delay connection and Closed this file." << std::endl;
}

void Log :: writeSpike(int index, double now){
	/*---------------------------------------------------
	indexはneuronの番号, nowは今の時刻
	全ての結果を記録する,reject_timeも残ったままなので注意
	---------------------------------------------------*/
	fprintf(fp_spike, "%d %lf\n", index, now);
}

void Log :: write_g(int step, Network* network){
	/*-------------------------------------------------
	普通は使わない関数. 多くても10sec程度で
	平均コンダクタンスの時間変化を知りたいときに使う.
	excitatory neuronsのグループとinhibitory neuronsのグループで計算する
	time Vm g_e g_i bg_e bg_i(exc) Vm g_e g_i bg_e bg_i(inh)
	----------------------------------------------------*/
	int i;
	double gE_mean, gI_mean, vE, vI;

	if(reject_time < step*dt){

		// state check
		vE = 0;
		vI = 0;
		std::cout << vE << vI << std::endl;
		for(i=0; i<N_e; i++){
			vE += network->neurons[i].get_volt_membrane();
		}
		for(i=N_e; i<N; i++){
			vI += network->neurons[i].get_volt_membrane();
		}

		fprintf(fp_g, "%lf ", step*dt);
		//=========== excitatory neuron =================
		gE_mean = 0;
		gI_mean = 0;
		// ネットワーク内
		for(i=0; i<N_e; i++){
			gE_mean += network->neurons[i].g_E->get_conductance();
			gI_mean += network->neurons[i].g_I->get_conductance();
		}
		fprintf(fp_g, "%lf %lf %lf ", vE/(double)N_e, gE_mean/(double)N_e, gI_mean/(double)N_e);

		//	backgroundの分も追加する
		gE_mean = 0;
		gI_mean = 0;
		for(i=0; i<N_e; i++){
			gE_mean += network->neurons[i].bg_E->get_conductance();
			gI_mean += network->neurons[i].bg_I->get_conductance();
		}
		fprintf(fp_g, "%lf %lf ", gE_mean/(double)N_e, gI_mean/(double)N_e);

		//=========== inhibitory neuron =================
		gE_mean = 0;
		gI_mean = 0;
		// ネットワーク内
		for(i=N_e; i<N; i++){
			gE_mean += network->neurons[i].g_E->get_conductance();
			gI_mean += network->neurons[i].g_I->get_conductance();
		}
		fprintf(fp_g, "%lf %lf %lf ", vI/(double)N_i, gE_mean/(double)N_i, gI_mean/(double)N_i);

		//	backgroundの分も追加する
		gE_mean = 0;
		gI_mean = 0;
		for(i=N_e; i<N; i++){
			gE_mean += network->neurons[i].bg_E->get_conductance();
			gI_mean += network->neurons[i].bg_I->get_conductance();
		}
		fprintf(fp_g, "%lf %lf ", gE_mean/(double)N_i, gI_mean/(double)N_i);

		//============== 全部のニューロン平均 ============
		vE = 0;
		for(i=0; i<N; i++){
			vE += network->neurons[i].get_volt_membrane();
		}
		gE_mean = 0;
		gI_mean = 0;
		// ネットワーク内
		for(i=0; i<N; i++){
			gE_mean += network->neurons[i].g_E->get_conductance();
			gI_mean += network->neurons[i].g_I->get_conductance();
		}
		fprintf(fp_g, "%lf %lf %lf ", vE/(double)N, gE_mean/(double)N, gI_mean/(double)N);

		//	backgroundの分も追加する
		gE_mean = 0;
		gI_mean = 0;
		for(i=0; i<N; i++){
			gE_mean += network->neurons[i].bg_E->get_conductance();
			gI_mean += network->neurons[i].bg_I->get_conductance();
		}
		fprintf(fp_g, "%lf %lf\n", gE_mean/(double)N, gI_mean/(double)N);

	}
}

void Log :: recordLv(int index, double now){
	/*---------------------------------------------------
	simulationがrunしている間の操作.reject timeを超えてから記録する

	neuron index番について操作
	spike_num[index]を１つincrement、それにともないLvの更新も行う
	-------------------------------------------------------*/
	if(reject_time < now){
		spike_num[index] += 1;
		// Lv valueの計算
		tpost[index] = now;
		Interval_post[index] = tpost[index] - tpre[index];
		if(spike_num[index]>2){
			Lv[index] += pow((Interval_post[index]-Interval_pre[index])/(Interval_post[index]+Interval_pre[index]), 2);
		}
		tpre[index] = tpost[index];
		Interval_pre[index] = Interval_post[index];
	}
}
void Log :: writeLv(){
	/*-------------------------------------------------------
	Lvfile, fratefileにLv、firing rateをneuron番号とともに書きこんでいく
	-------------------------------------------------------*/
	std::cout << "Writing firing rate and Lv" << std::endl;
	// open pointor
	std::cout << Lvfile << "と" << fratefile << "を書き込み用で開く" << std::endl;
	FILE *fp_Lv = fopen(Lvfile.c_str(), "w");
	FILE *fp_frate = fopen(fratefile.c_str(), "w");

	for(int i=0; i<N; i++){
		Lv[i] = 3 * Lv[i] / (spike_num[i]-2);
	}
	for(int i=0; i<N; i++){
		fprintf(fp_Lv, "%d %lf\n", i, Lv[i]);
	}
	for(int i=0; i<N; i++){
		fprintf(fp_frate, "%d %lf\n", i, spike_num[i]/(total_time-reject_time) * 1000.0);
	}

	std::cout << "\t書き出し終了. CLOSE files." << std::endl;
	if(fp_frate!=NULL)fclose(fp_frate);
	if(fp_Lv!=NULL)fclose(fp_Lv);

	//---- log -------
	// excitatory
	double tmp_f = 0;
	double tmp_l = 0;
	for(int i=0; i<N_e; i++){
		tmp_f += spike_num[i]/(total_time-reject_time) * 1000.0;
		tmp_l += Lv[i];
	}
	std::cout << "Mean over Excitatory Neurons" << std::endl;
	std::cout << "\tfiring rate : " << tmp_f/N_e << " Hz" << std::endl;
	std::cout << "\tLv : " << tmp_l/N_e << std::endl;
	// inhibitory
	tmp_f = 0;
	tmp_l = 0;
	for(int i=N_e; i<N; i++){
		tmp_f += spike_num[i]/(total_time-reject_time) * 1000.0;
		tmp_l += Lv[i];
	}
	std::cout << "Mean over Inhibitory Neurons" << std::endl;
	std::cout << "\tfiring rate : " << tmp_f/N_i << " Hz" << std::endl;
	std::cout << "\tLv : " << tmp_l/N_i << std::endl;
}
void Log :: write_wave(Network* network, std::string file){
	/*-------------------------------------------------------
	全てのニューロンについて番号とともに書き出す。
	neuron番号　waveの数　amp1 Hz1 delta1 amp2 Hz2 delta2...
	-------------------------------------------------------*/
	std::cout << file << " にexcitatory conductance に入れるwaveを記録していく" << std::endl;
	FILE *fp = fopen(file.c_str(), "w");
	int N_wave = 0;
	double amp, freq, delta;
	for(int i=0; i<this->N; i++){
		N_wave = network->neurons[i].bg_E->get_N_wave();
		fprintf(fp, "%d %d ", i, N_wave);
		for(int j=0; j<N_wave; j++){
			amp = network->neurons[i].bg_E->get_amplitude(j);
			freq = network->neurons[i].bg_E->get_omega(j);
			delta = network->neurons[i].bg_E->get_delta(j);
			fprintf(fp, "%lf %lf %lf", amp, freq, delta);
		}
		fprintf(fp, "\n");
	}
	if(fp!=NULL)fclose(fp);
	std::cout << "->" << file << "への書き込み終わり" << std::endl;
}
void Log :: printLog(int step, Network* network){
	if(step%bin==0){
		_log(step, network);
	}
}
void Log :: _log(int step, Network* network){
	int i;
	double gE_mean, gI_mean, vE, vI;
	// state check
	vE = 0;
	vI = 0;
	gE_mean = 0;
	gI_mean = 0;
	for(i=0; i<N_e; i++){
		vE += network->neurons[i].get_volt_membrane();
	}
	for(i=N_e; i<N; i++){
		vI += network->neurons[i].get_volt_membrane();
	}
	for(i=0; i<N; i++){
		gE_mean += network->neurons[i].g_E->get_conductance();
		gI_mean += network->neurons[i].g_I->get_conductance();
	}
	printf("time %.0lf ms. membrane E: %lf mV, I: %lf mV\n", step*dt, vE/(double)N_e, vI/(double)N_i);
	std::cout << "\tg in inter-connect: E -> " << gE_mean/(double)N << " ";
	std::cout << "I -> " << gI_mean/(double)N << std::endl;

	/*------ all conductance -------------
	backgroundの分も追加する
	--------------------------------*/
	for(i=0; i<N; i++){
		gE_mean += network->neurons[i].bg_E->get_conductance();
		gI_mean += network->neurons[i].bg_I->get_conductance();
	}
	std::cout << "\tg in all-connect: E -> " << gE_mean/(double)N << " ";
	std::cout << "I -> " << gI_mean/(double)N << std::endl;
}

Log :: ~Log(){
	std::cout << "Closing file in Log" << std::endl;
	if(fp_spike!=NULL)fclose(fp_spike);
	if(fp_g!=NULL)fclose(fp_g);
	//--delelte--
	delete [] Lv;
	delete [] rate;
	delete [] spike_num;
	delete [] tpre;
	delete [] tpost;
	delete [] Interval_pre;
	delete [] Interval_post;
}
