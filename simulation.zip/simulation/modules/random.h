#ifndef RANDOM_H
#define RANDOM_H

#include<SFMT.h>

double Uniform(sfmt_t *sfmt);
double rand_normal(double mu, double sigma, sfmt_t *sfmt);
double rand_Lnormal(double mu, double sigma, sfmt_t *sfmt);

#endif
