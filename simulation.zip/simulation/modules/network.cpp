#include<iostream>
#include<cmath>
#include<omp.h>
#include<SFMT.h>
#include<macro.h>
#include<random.h>
#include<conductance.h>
#include<neuron.h>
#include<connect.h>
#include<network.h>

Network :: Network(int argN): N(argN){
}

void Network :: set_neurons(Neuron *neuron, Connect *connect){
	/*---------------------------------------------
	networkを作成する
	neuron, connectionは外で作成して与える形をとる.
	max_delay_stepのあたいも求める
	---------------------------------------------*/
	//=========== ネットワークのneuronと結合をセットする =================
	std::cout << "Setting the number of Neurons and Connection in Network" << std::endl;
	this->neurons = neuron;
	this->connect = connect;

	//============ 最大のdelayを取得 ================-
	// これはringbufferを作るのに必要な値
	this->max_delay_step = 0;
	for(int i=0; i<N; i++){
		// k番目の結合のdelayを調べる
		for(int k=0; k<connect->getLength(i); k++){
			// max_delay_stepの方が短ければ
			if(this->max_delay_step < connect->getDelay(i,k)){
				this->max_delay_step = connect->getDelay(i,k);
			}
		}
	}
	// １つ分だけ多めにとっておく
	this->max_delay_step = this->max_delay_step + 1;
	std::cout << "max_delay_step: " << this->max_delay_step << std::endl;
}

void Network :: init_network(int seed, int N_seed){
	/*----------------------------------------------
	ring bufferとsimulation用の乱数の初期化.
	並列数分だけ乱数を用意する
	----------------------------------------------*/
	std::cout << "Initializing time_step and buffer in Network" << std::endl;

	//============ 時刻の初期化 =================
	now_step = 0;

	//============= ringbuffer 初期化 =====================
	ring_buffer_e = d2array(N, max_delay_step);
	ring_buffer_i = d2array(N, max_delay_step);

	//=============== initialize seed ===============
	std::cout << "Initializing seeds in Network for running simulation"<< std::endl;
	this->N_seed = N_seed;
	this->seed = seed;

	sfmt = new sfmt_t[N_seed];
	for(int i=0; i<N_seed; i++){
		std::cout << "\tseed[" << i << "] = " << seed+i << ", ";
		sfmt_init_gen_rand(sfmt+i, i+seed);
	}
	std::cout << std::endl;
}

void Network :: set_spike_in_ringbuffer(sfmt_t *sfmt_out){
	/*-----------------------------------------------------
	Simulationを走らせる前に一部のneuronがspikeしたことにしておく.
	max_delay_stepの間に発火率5Hzで発火したことにする.
	-----------------------------------------------------*/
	if((ring_buffer_e==NULL)|(ring_buffer_i==NULL)){
		std::cout << "ring bufferの初期化がされていない" << std::endl;
		std::exit(1);
	}

	// neuron iの発火確率. 平均5Hzとする
	double prob = 5 * max_delay_step * dt / 1000.0;

	std::cout << "===== Setting Pre-spike ======" << std::endl;
	std::cout << "  " << max_delay_step << "step間に発火する確率: " << prob << std::endl;
	std::cout << "  Pre-Spike neuron:" << std::endl;
	int j, k;
	// 何ステップ前に発火したか
	int past_step;
	for(int i=0; i<N; i++){
		if(Uniform(sfmt_out)<prob){
			// 発火時刻も乱数で取得
			past_step =  max_delay_step - (int)(max_delay_step * Uniform(sfmt_out));
			std::cout << i << " " << past_step - max_delay_step << "ms, ";

			if(neurons[i].neuron_type==0){
				//if excitatory:
				for(k=0; k<connect->getLength(i); k++){
					// 結合先のindex
					j = connect->getIndex(i, k);
					// ring_bufferに書き込み
					ring_buffer_e[j][(past_step+connect->getDelay(i,k))%max_delay_step] += connect->getWeight(i, k);
				}
			}else{
				//if inhibitory neuron
				for(k=0; k<connect->getLength(i); k++){
					// 結合先のindex
					j = connect->getIndex(i, k);
					// ring_bufferに書き込み
					ring_buffer_i[j][(past_step+connect->getDelay(i,k))%max_delay_step] += connect->getWeight(i,k);
				}
			}
		}
	}
	std::cout << "\n  END: pre-set" << std::endl;
}

double Network :: get_now(){
	/* nowをそのまま扱うと誤差が出てくる*/
	now = now_step * dt;
	return now;
}

void Network :: update(){
	/*-------------------------------------------
	neuron全体の時間発展
	iは時間発展を見るニューロンの番号
	spikeした場合はneuron jにdelay_step[j][i]後にconnection[j][i]分のコンダクタンスが加わる
	ここにはexcitory neuronとinhibitory neuronしかなくタイプごとに結合を増加させるコンダクタンスが異なることに注意
	-----------------------------------------------------*/
	int j, k;
	#pragma omp parallel for private(j, k) schedule(static)
	for(int i=0; i<N; i++){

		// ============ neuron iがspikeしたか判定 ============
		if(neurons[i].isFiring(now)){

			if(neurons[i].neuron_type==0){
				//============ if excitatory neuron =============
				for(k=0; k<connect->getLength(i); k++){
					// 結合先のindex
					j = connect->getIndex(i, k);

					// ring_bufferに書き込み
					#pragma omp atomic
					ring_buffer_e[j][(now_step+connect->getDelay(i,k))%max_delay_step] += connect->getWeight(i, k);
				}
			}else{
				//============ if inhibitory neuron ============
				for(k=0; k<connect->getLength(i); k++){
					// 結合先のindex
					j = connect->getIndex(i, k);

					// ring_bufferに書き込み
					#pragma omp atomic
					ring_buffer_i[j][(now_step+connect->getDelay(i,k))%max_delay_step] += connect->getWeight(i,k);
				}
			}
		}

		//============= Euler update =============
		//  次の時刻に膜電位,コンダクタンスを進める, spikeしていたら閾値が上がる
		neurons[i].allupdate(now, ring_buffer_e[i][now_step%max_delay_step], ring_buffer_i[i][now_step%max_delay_step], sfmt+omp_get_thread_num());

		//============= Clean ring buffer at now step ========
		ring_buffer_e[i][now_step%max_delay_step] = 0;
		ring_buffer_i[i][now_step%max_delay_step] = 0;
	}

	//全部neuronの更新が終わったら時刻を１つ進める
	now_step += 1;
	get_now();
}

Network :: ~Network(){
	std::cout << "delete Connect and Delay" << std::endl;
	delete connect;
	delete [] neurons;
}
