/*-------------------------------------
conductance classの定義
backgroundのコンダクタンスはinter connectionのconductanceの拡張にすぎない
Conductance class
定数:
- 時定数: tau
- 最低コンダクタンス: g0
変数:
- コンダクタンスの値: g

Backgorund class
定数:
- 波の数: N_wave
- 波の大きさ：*Amplitude
- 波の振動数; *omega
- 位相のずれ: delta
- ノイズの時間変化幅: dt_noise
関数:
update関数がノイズ波の要素が追加されるのでoverwriteする
-------------------------------------*/
#ifndef CONDUCTANCE_H
#define CONDUCTANCE_H
#include<SFMT.h>

class Conductance{
	/*---------------------
	MATモデルで変化する
	----------------------*/
protected:
	double g;
	double g0;
	double tau;
public:
	Conductance();
	virtual void set_g0(double g0);
	virtual void set_tau(double tau);
	virtual void update(double input);
	/*他neuronからのinputのこと*/
	virtual double get_conductance();
	virtual ~Conductance();
};

class Background : public Conductance {
	double sigma; // gauss noise の大きさ
	double *amplitude;
	double *omega;
	double *delta; //phaseのズレ
	int N_wave;
	static const double dt_noise;
private:
	virtual double makeNoise(sfmt_t *sfmt);
public:
	Background();
	virtual void set_N_wave(int N_wave);
	/* 基本的には振動要素がある(1)かないか(0)で２つ入るということはないものと考えている */
	virtual void set_sigma(double sigma);
	/* white noiseの大きさを決める*/
	virtual void set_wave(int i, double a, double w, double d);
	/* sin波の影響を決める */
	virtual double get_dt_noise();
	virtual double get_sigma();
	virtual int get_N_wave();
	virtual double get_amplitude(int i);
	virtual double get_omega(int i);
	virtual double get_delta(int i);
	virtual void update(double now, sfmt_t *sfmt);
	virtual ~Background();
};

#endif
