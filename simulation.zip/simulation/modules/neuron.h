/*-----------------------------
2020/1/26 編集 endo daisuke
Neuron classの定義
以下の時間の単位は全てmsec.
定数:
- 膜電位の時定数 : tau_membrane
- refractory period : tref
- reacky volt : Volt_L, Volt_E, Volt_I, Volt_bg_E, Volt_bg_I
変数:
- conductance
	- inter connection : g_E, g_I
	- background : bg_E, bg_I
- 発火の閾値 : theta
- 膜電位 : volt_membrane
- 最後の発火時刻 : tlast
- 現在時刻において発火しているか : spike_flg firing -> True
設計:
	obeject思考に基づくなら全て変数はprivateにすべきだ。
	だが、thetaとconductanceはpublicにしてしまう。
	いちいち関数を作るのがめんどくさくなったから。
------------------------------*/
#ifndef NEURON_H
#define NEURON_H
#include<threshold.h>
#include<conductance.h> // condactanceクラスの定義が必要

class Neuron{
	double volt_membrane;
	double tau_membrane;
	static const double tref;
	double tlast; //最後の発火時刻
	bool spike_flg;
public:
	static const double Volt_L, Volt_E, Volt_I, Volt_bg_E, Volt_bg_I; // 外から参照できるようにする
	Conductance *g_E, *g_I;
	Background *bg_E, *bg_I;
	Threshold *theta;
	int neuron_type; // 0はexc, 1はinhとしている
private:
	virtual void init_pointer();
	virtual void update_volt(double now);
public:
	Neuron();
	virtual void set_neuron_type(int neuron_type);
	/* neuronの種類を表すflgを立てる.
	0がexc, 1はinh*/
	virtual void set_volt_membrane(double volt_membrane);
	/*初期のvolt_membraneをsetする*/
	virtual void set_tau_membrane(double tau_membrane);
	/*膜電位の時定数をsetする*/
	virtual double get_volt_membrane();
	/*膜電位をgetする*/
	virtual bool isFiring(double now);
	/*発火の判定*/
	virtual bool getSpike();
	virtual void allupdate(double now, double input_E, double input_I, sfmt_t *sfmt);
	virtual ~Neuron();
};

#endif
