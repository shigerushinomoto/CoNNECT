#include<iostream>
#include<cmath>
#include<omp.h>
#include<SFMT.h>
#include<macro.h>
#include<random.h>
#include<conductance.h>
#include<threshold.h>
#include<neuron.h>

const double Neuron :: tref = 1;
const double Neuron :: Volt_L = -70;
const double Neuron :: Volt_E = 0;
const double Neuron :: Volt_I = -80;
const double Neuron :: Volt_bg_E = 0;
const double Neuron :: Volt_bg_I = -80;

Neuron :: Neuron(){
	/*-----------------------------------
	コンストラクタ
	最終発火時刻はrefractory periodに引っかからないくらい前にしておく
	-----------------------------------*/
	init_pointer();
	// 最後の発火時間を昔にしておく
	tlast = - tref;
}
void Neuron :: init_pointer(){
	/*-----------------------------------
	ポインタの初期化.
	コンダクタンスと膜電位はポインタである.(このクラス定義の仕方は正直あまり良くない)
	具体的なパラメータはあとで代入する。
	globalの変数にしているので直接いじる*
	-----------------------------------*/
	g_E = new Conductance();
	g_I = new Conductance();
	bg_E = new Background();
	bg_I = new Background();
	theta = new Threshold();
}

void Neuron :: set_neuron_type(int neuron_type){
	/*-----------------------------------
	基本的には2種類しか用意しない
	0 -> excitatory
	1 -> inhibitory
	-----------------------------------*/
	this->neuron_type = neuron_type;
}

void Neuron :: set_volt_membrane(double volt_membrane){
	/*-----------------------------------
	初期の膜電位を設定する
	あまりにおかしい値は除外する
	-----------------------------------*/
	if(volt_membrane>0){
		std::cerr << "Value Error. An initial volt_membrane must be re-choosen" << std::endl;
		std::exit(1);
	}
	this->volt_membrane = volt_membrane;
}

void Neuron :: set_tau_membrane(double tau_membrane){
	/*-----------------------------------
	tau_membraneの設定をする
	-----------------------------------*/
	if(tau_membrane<=0){
		std::cerr << "Value Error. your choosen tau_membrane <= 0. tau_membrane must be greater than 0." << std::endl;
		std::exit(1);
	}
	this->tau_membrane = tau_membrane;
}

double Neuron :: get_volt_membrane(){
	/*-----------------------------------
	膜電位を取得する
	-----------------------------------*/
	return volt_membrane;
}

bool Neuron :: isFiring(double now){
	/*-----------------------------------
	発火する条件かどうかの判定を行う
	かつ発火フラグの建て直しをする
	-----------------------------------*/
	if(volt_membrane>=theta->get_theta()){
		//theta->increase_theta();
		spike_flg = true;
		tlast = now;
		return true;
	}
	spike_flg = false;
	return false;
}

bool Neuron :: getSpike(){
	/*-----------------------------------
	spike_flgを返す.spikeしているかどうかを表す
	bool値
	-----------------------------------*/
	return spike_flg;
}

void Neuron :: update_volt(double now){
	/*-----------------------------------
	膜電位v_mの時間発展を行う.
	Euler法を用いている.
	expで減衰して, コンダクタンスの影響の電位増加が入る
	refractory periodではコンダクタンスによる電位の増加なし.
	refractory periodの入れ方は複数あるがそのうちの1つに過ぎない,
	Teramae et al. 2012　の入れ方を参考にした
	-----------------------------------*/

	double dv = 0;
	dv = - (volt_membrane-Volt_L)/tau_membrane + Constant_Current;
	/* recractory time内では電位の増加をさせない*/
	if (now > tlast + tref){
		dv += - (
			g_E->get_conductance()*(volt_membrane-Volt_E)
			+ g_I->get_conductance()*(volt_membrane-Volt_I)
			+ bg_E->get_conductance()*(volt_membrane-Volt_bg_E)
			+ bg_I->get_conductance()*(volt_membrane-Volt_bg_I)
		);
	}
	// 時間刻みをかける
	volt_membrane += dv * dt;

	// exit if this volt_membrane is impossible value
	if((volt_membrane>200)|(volt_membrane<-200)){
		#pragma omp critical
		{
			std::cerr << "Value Error. volt_membrane is beyond expected : " << volt_membrane << "mV in " << now << " ms"<< std::endl;
			std::cerr << "Neuron type" << neuron_type << std::endl;
			std::cerr << "Conductance:" << std::endl;
			std::cerr << "\t" << g_E->get_conductance() << std::endl;
			std::cerr << "\t" << g_I->get_conductance() << std::endl;
			std::cerr << "\t" << bg_E->get_conductance() << std::endl;
			std::cerr << "\t" << bg_I->get_conductance() << std::endl;
			std::cerr << "Threshold:" << std::endl;
			std::cerr << "\t" << theta->get_theta() << std::endl;
		}
		std::exit(1);
	}
}

void Neuron :: allupdate(double now, double input_E, double input_I, sfmt_t *sfmt){
	/*-----------------------------------
	膜電位, コンダクタンス, 発火閾値の時間発展
	時間発展の順番に気を付ける. 必ず膜電位を最初に更新すること
	他のニューロンからの入力（コンダクタンス)をinput_E, input_Iとしていれる.
	この中では発火の判定とかは行わない.
	純粋に時間発展を行うだけ
	発火した場合は膜電位の上昇を行う
	-----------------------------------*/

	// 膜電位のupdate
	update_volt(now);

	// 他のneuronからのinputを入れる
	g_E->update(input_E);
	g_I->update(input_I);

	// backgroundのupdate, nowを入れるとnow+1自国の値に変わる
	bg_E->update(now, sfmt);
	bg_I->update(now, sfmt);

	// 閾値のupdate
	theta->update();

	// spiekしていたら閾値が上昇
	if(spike_flg){
		theta->increase_theta();
	}
}

Neuron :: ~Neuron(){
	/*ポインタの解放*/
	delete g_E;
	delete g_I;
	delete bg_E;
	delete bg_I;
	delete theta;
}
