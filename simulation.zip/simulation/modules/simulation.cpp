#include<iostream>
#include<cmath>
#include<omp.h>
#include<SFMT.h>
#include<macro.h>
#include<random.h>
#include<conductance.h>
#include<neuron.h>
#include<network.h>
#include<log.h>
#include<simulation.h>


Simulation :: Simulation(int argN_e, int argN_i) : N_e(argN_e), N_i(argN_i), N(argN_e+argN_i){
	// neuronの数を指定する
	std::cout << "Setting Neuron parameters." << std::endl;
	std::cout << "\tExcitatory Neurons : " << N_e << std::endl;
	std::cout << "\tInhibitory Neurons : " << N_i << std::endl;
}

void Simulation :: init_random(int seed){
	/**--------------------------------------------------------
	Simulationでneuronやconnectionを作成するが,
	そのための乱数の初期化
	*--------------------------------------------------------*/
	std::cout << "Making Neuon, PSP connection, delay connectionのための乱数を初期化する: " << seed << std::endl;

	//networkの生成に使う乱数
	this->sfmt = new sfmt_t;
	sfmt_init_gen_rand(sfmt, seed);

	//simultaionのrunにつかう乱数
	this->seed = seed+1;
}

void Simulation :: makeNeuron(double alpha_e, double alpha_i, double amplitude_mean, int N_wave, double* freqs, int* N_fs){
	/*--------------------------------------------------------
	simulationクラスのneuronポインタを作成
	parameterはここで編集する
	*--------------------------------------------------------*/
	if(N_wave<0){
		std::cout << "N_waveは0以上です. N_wave =" << N_wave << std::endl;
		std::exit(1);
	}
	//======================= parameters =======================
	// neuronの種類を決める
	static const int excitatory_type = 0;
	static const int inhibitory_type = 1;
	static const double excitatory_tau_membrane = 20;
	static const double inhibitory_tau_membrane = 10;

	// 閾値に関わる値たち
	static const double omega_exc = -55;
	static const double omega_inh = -57;
	std::cout << "\tThreshold omega E: " << omega_exc << "mV I: " << omega_inh << "mV" << std::endl;

	// conductanceに関わる定数たち
	static const double tau_in_e = 1.0;
	static const double tau_in_i = 2.0;
	static const double tau_bg_e = 2.7;
	static const double tau_bg_i = 10.5;
	std::cout << "\tConductance time constant in inter-connection ";
	std::cout << "E: " << tau_in_e << "ms I : " << tau_in_i << "ms"<< std::endl;
	std::cout << "\tConductance time constant in background ";
	std::cout << "E: " << tau_bg_e << "ms I : " << tau_bg_i << "ms"<< std::endl;
	const double g0_bg_e = 10.8/350.0 * alpha_e;
	const double g0_bg_i = 51.3/350.0 * alpha_i;
	const double sigma_bg_e = 2.85/350.0 * sqrt(alpha_e);
	const double sigma_bg_i = 6.26/350.0 * sqrt(alpha_i);

	std::cout << "Background Conductance" << std::endl;
	std::cout << "\texc: " << g0_bg_e << ", inh: " << g0_bg_i << std::endl;

	//====================  waveについての操作 =======================
	std::cout << "Setting wave" << std::endl;
	//double amplitude_mean = 0.015;
	//double freqs[] = {7, 10, 20};
	//int N_fs[] = {100, 100, 100};
	//int N_wave = 3; // 全体に何種類の波をいれるか
	// waveを入れるニューロンの数の確認
	int tmp = 0;
	for(int i=0; i<N_wave; i++){
		tmp += N_fs[i];
	}
	if(tmp>=this->N){
		std::cout << "waveの数がニューロンの数を超えている" << std::endl;
		std::exit(1);
	}
  std::cout << "\tThe mean of A: " << amplitude_mean << std::endl;
	std::cout << "\tThe number of the type of wave: " << N_wave << std::endl << "\t\t";
	for(int i=0; i<N_wave; i++){
		std::cout << freqs[i] << "Hz :" << N_fs[i] << " ";
	}
	std::cout << std::endl;
	/* excitatory conductanceだけに揺らぎが入るとしている.
	N_eとN_iに対応したratioだけwaveを入れていく.
	変な値は弾く
	代入しやすいように変形させる
	i-th waveは
	N_fs_pre[i]からN_fs_post[i]の間に入る
	注意する点としては、この数はexcitatoryとinhibitoryを合わせたものである
	*/
	double ratio = (double)N_e / (double)N;
	int *N_fs_pre, *N_fs_post;
	if(N_wave>0){
		N_fs_pre = new int [N_wave];
		N_fs_post = new int [N_wave];
		N_fs_pre[0] = 0;
		N_fs_post[0] = N_fs[0];
		for(int i=0; i<N_wave-1; i++){
			N_fs_pre[i+1] = N_fs_post[i];
			N_fs_post[i+1] = N_fs[i+1] + N_fs_post[i];
		}
	}

	//======================= neuronの作成 =======================
	/*
	neuronの膜電位, 閾値の設定,
	neuronがもつコンダクタンスの設定を行なっている.
	このモデルでは波が入るのは excitatory conductance だけである.
	excitatory neuronとinhibitory neuron両方に入れる
	*/
	std::cout << "========= START: Making Neurons =========" << std::endl;
	Neuron *neurons = new Neuron[N];

	//====== excitatory neuronの設定を行う ======
	std::cout << "\tExcitatory Neurons :" << N_e << std::endl;
	for(int i=0; i<N_e; i++){
		neurons[i].set_neuron_type(excitatory_type);
		neurons[i].set_volt_membrane(5*Uniform(sfmt)+neurons[i].Volt_L);
		neurons[i].set_tau_membrane(excitatory_tau_membrane);
		//---neuronごとにthresholdの設定をする---
		neurons[i].theta->set_omega(omega_exc);
		neurons[i].theta->set_alpha(0, rand_normal(1.5, 0.25, sfmt));
		neurons[i].theta->set_alpha(1, 0.5);
		//---neuronごとにconductanceの設定---
		// inter-connection
		neurons[i].g_E->set_g0(0);
		neurons[i].g_E->set_tau(tau_in_e);
		neurons[i].g_I->set_g0(0);
		neurons[i].g_I->set_tau(tau_in_i);
		// from background excitatory
		neurons[i].bg_E->set_g0(g0_bg_e);
		neurons[i].bg_E->set_tau(tau_bg_e);
		neurons[i].bg_E->set_sigma(sigma_bg_e);
		neurons[i].bg_E->set_N_wave(0); // 一時的な代入
		for(int j=0; j<N_wave; j++){
			/*一部に波を入れる*/
			if((N_fs_pre[j]*ratio <= i)&&(i < N_fs_post[j]*ratio)){
				neurons[i].bg_E->set_N_wave(1);
				neurons[i].bg_E->set_wave(0,
					(Uniform(sfmt)+0.5)*amplitude_mean,
					2*M_PI*freqs[j]/1000.0,
					2*M_PI*Uniform(sfmt));
			}
		}
		// from background inhibitory
		neurons[i].bg_I->set_g0(g0_bg_i);
		neurons[i].bg_I->set_tau(tau_bg_i);
		neurons[i].bg_I->set_sigma(sigma_bg_i);
		neurons[i].bg_I->set_N_wave(0);
	}

	//====== inhibitory neuronの設定を行う ======
	std::cout << "\tInhibitory Neurons :" << N_i << std::endl;
	for(int i=N_e; i<N; i++){
		neurons[i].set_neuron_type(inhibitory_type);
		neurons[i].set_volt_membrane(5*Uniform(sfmt)+neurons[i].Volt_L);
		neurons[i].set_tau_membrane(inhibitory_tau_membrane);
		//---neuronごとにthresholdの設定をする---
		neurons[i].theta->set_omega(omega_inh);
		neurons[i].theta->set_alpha(0, 3);
		neurons[i].theta->set_alpha(1, 0);
		//---neuronごとにconductanceの設定---
		// inter-connection
		neurons[i].g_E->set_g0(0);
		neurons[i].g_E->set_tau(tau_in_e);
		neurons[i].g_I->set_g0(0);
		neurons[i].g_I->set_tau(tau_in_i);
		// from background excitatory
		neurons[i].bg_E->set_g0(g0_bg_e);
		neurons[i].bg_E->set_tau(tau_bg_e);
		neurons[i].bg_E->set_sigma(sigma_bg_e);
		neurons[i].bg_E->set_N_wave(0); //一時的な代入
		// waveを入れる時はHzをmsecにあうように入れる
		for(int j=0; j<N_wave; j++){
			if((N-N_fs_pre[j]*(1-ratio)>i)&&(i>=N-N_fs_post[j]*(1-ratio))){
				neurons[i].bg_E->set_N_wave(1);
				neurons[i].bg_E->set_wave(0,
					(Uniform(sfmt)+0.5)*amplitude_mean,
					2*M_PI*freqs[j]/1000.0,
					2*M_PI*Uniform(sfmt));
			}
		}
		// from background inhibitory
		neurons[i].bg_I->set_g0(g0_bg_i);
		neurons[i].bg_I->set_tau(tau_bg_i);
		neurons[i].bg_I->set_sigma(sigma_bg_i);
		neurons[i].bg_I->set_N_wave(0);
	}

	//======================= いらない変数の削除 =======================
	if(N_wave>0){
		delete [] N_fs_pre;
		delete [] N_fs_post;
	}

	std::cout << "====== END: Making Neuron ======" << std::endl;
	this->neurons = neurons;
}
double** Simulation :: makeConnection(){
	/*----------------------------------------
	コンダクタンスによる結合を作成する.
	PSPが10mVは超えないようにしている.
	ここではコンダクタンスからPSPの変換は
	macro.hに定義されている定数を使用している.
	----------------------------------------*/
	std::cout << "====== START: Making Conductance connection ======" << std::endl;
	int i, j;
	double **connection = d2array(N, N);
	for(i=0; i<N; i++){
		for (j=0; j<N_e; j++){
			/*
			Excitatory Neuron jからiへの結合は0.125の割合で存在する.
			コンダクタンスは対数正規分布.
			EPSPが10mVを越える時はre-sampleする
			*/
			if((i!=j)&(Uniform(sfmt)<0.125)){
				do{
					connection[i][j] = rand_Lnormal(Ge_mu, Ge_sigma, sfmt);
				}while(Ge2EPSP*connection[i][j]>10.0);
			}
		}
		for(j=N_e; j<N; j++){
			/*
			Inhibitory Neuron jからiへの結合は0.25の割合で存在する
			コンダクタンスはガウス分布から生成される.
			0mVより小さい時はre-sampleする.
			IPSPの方は線形変換なので明示的にコンダクタンスからの変換は入れる必要はない
			*/
			if((i!=j)&(Uniform(sfmt)<0.25)){
				do{
					connection[i][j] = rand_normal(Gi_mu, Gi_sigma, sfmt);
				}while(connection[i][j]<=0);
			}
		}
	}
	std::cout << "\tEND: Made Conductance connection" << std::endl;
	return connection;
}
int** Simulation :: makeDelay(double **connection){
	/*----------------------------------------
	コンダクタンスの結合が存在するところにdelay [step単位] を入れる.
	excitatory neuronからの結合は 3 ~ 5 msの遅れ
	inhibitory neuronからの結合は 2 ~ 4 msの遅れ
	注意:
		delayはmsで求めているが, stepに変換する時に無駄な計算が出るので, step数で出力している
	----------------------------------------*/
	std::cout << "====== START: Making synaptic delay ======" << std::endl;
	int **delay_step = i2array(N, N);
	int i, j;
	for(i=0; i<N; i++){
		for(j=0; j<N; j++){
			if (connection[i][j] > 0){
				if (j<N_e){
					delay_step[i][j] = (int)((Uniform(sfmt) * 2 + 1 + 2)/dt);
				}else{
					//delay_step[i][j] = (int)(((Uniform(sfmt) * (2-dt))+dt)/dt);//(0は流石に変なので1*dt(=0.1)から2.0にする)
					delay_step[i][j] = (int)((Uniform(sfmt) * 2 + 2)/dt);
				}
			}
		}
	}
	std::cout << "\tEND: Made delay" << std::endl;
	return delay_step;
}

void Simulation :: init_log(std::string spikefile, std::string Lvfile, std::string fratefile, std::string pspfile, std::string delayfile){
	std::cout << "====== Initialize Log instance and file open ======" << std::endl;
	log = new Log;
	log->fileopen(spikefile, Lvfile, fratefile, pspfile, delayfile);
	//通常は使わない. コンダクタンス記録
	//log->open_g();
}

void Simulation :: set_network(){
	/*----------------------------------------------
	N_seedはsimulationの時に並列する乱数の数を入れる。
	OpenMPで並列するので、スレッドごとに違うタネを使って計算するようにする
	OpenMPの並列数を入れる
	----------------------------------------------*/
	std::cout << "====== START: Making Network ======" << std::endl;
	log->set_size(this->N, this->N_e);

	//===============  コンダクタンスの結合を生成 ===============
	std::cout << "\tCreate PSP connection" << std::endl;
	double **connection = this->makeConnection();

	//===============  delayを作成 ===============
	// （これは必ずコンダクタンスの結合を作成した後に入れる)
	std::cout << "\tCreate Delay connection" << std::endl;
	int **delay_step = this->makeDelay(connection);

	// fileに記録
	log->writeConnect(connection);
	log->writeDelay(delay_step);

	//=============== 隣接リストへ変換 ===============
	// コンダクタンスの結合とsynaprtic delayを隣接リストに変換してメモリを節約
	Connect *connect = new Connect;
	connect->makeList(N, connection, delay_step);

	//=============== networkのset ===============
	// 空のnetworkを作り, neuronと結合を入れる
	network = new Network(N);
	network->set_neurons(neurons, connect);
	std::cout << "\tEND: Made Network" << std::endl;

	// 解放する
	d2free(connection);
	i2free(delay_step);
}

void Simulation :: write_wave(std::string wavefile){
	if(neurons==NULL){
		std::cout << "neuronsが空" << std::endl;
	}
	log->write_wave(network, wavefile);
}

void Simulation :: run(double total_time, double reject_time, int N_seed){
	/*-------------------------------------------------------
	spikeを記録するneuronの数を変えたいときは
	#pragma omp parallel for 以下のforループの中をいじる
	-------------------------------------------------------*/
	//=============== 時刻, ringbuffer, 乱数の初期化 ===============
	network->init_network(this->seed, N_seed);

	//=============== logの初期化 ===============
	log->set_time(total_time, reject_time);
	const int total_step = (int)(total_time/dt);

	//=============== 記録するneuronの設定 ===============
	static const int exc_begin = 0;
	static const int exc_end = 320;
	static const int inh_begin = N-80;
	static const int inh_end = N;

	std::cout << "spikeを記録するneuronは以下:";
	std::cout << exc_begin << " <= index < " << exc_end << " OR ";
	std::cout << inh_begin << " <= index < " << inh_end << std::endl;

	if(exc_begin > exc_end){
		std::cout << "Error: 記録するneuronの番号にミスがある" << std::endl;
	}
	if(inh_begin > inh_end){
		std::cout << "Error: 記録するneuronの番号にミスがある" << std::endl;
	}

	// ==================== Set spikes in ringbuffer ====================
	std::cout << "スタート前のspikeをsetする" << std::endl;
	network->set_spike_in_ringbuffer(sfmt);

	//===================== main run =====================
	std::cout << "========== START: Running simulation: total_step = " << total_step << "============" << std::endl;
	int step = 0;
	for(step=0; step<total_step; step++){
		// logの出力
		log->printLog(step, network);
		//通常は使わない.コンダクタンス記録
		//log->write_g(step, network);

		// 時刻の更新. 関数内で並列計算している
		network->update();

		// spike, firing rate, Lv の記録
		// 並列に操作しても問題ないところは並列計算
		#pragma omp parallel for
		for(int i=0; i<N; i++){
			// spike判定.
			if(network->neurons[i].getSpike()){
				// spike timeを記録するのは一部
				if( ((exc_begin <= i)&(i < exc_end)) | ((inh_begin <= i )&(i < inh_end)) ){
					#pragma omp critical
					{log->writeSpike(i, step*dt);}
				}
				// 全てのneuronについてfiring rate, Lvは記録して行く
				log->recordLv(i, step*dt);
			}
		}
	}
	std::cout << "============ END: Simulation: simulationの現在時刻は now = " << network->get_now() << "============" << std::endl;

	//===============  結果のLv値,firing rateを記録する ===============
	log->writeLv();
}
Simulation :: ~Simulation(){
	std::cout << "Delete Log and Network" << std::endl;
	delete log;
	delete network;
}
