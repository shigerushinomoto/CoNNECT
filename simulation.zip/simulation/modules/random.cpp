#include<iostream>
#include<cmath>
#include<SFMT.h>
#include<macro.h>
#include<random.h>
// 一様分布
double Uniform(sfmt_t *sfmt){
  return sfmt_genrand_real3(sfmt);
}
// Normal分布
double rand_normal(double mu, double sigma, sfmt_t *sfmt){
    double z=sqrt( -2.0*log(Uniform(sfmt)) ) * sin( 2.0*M_PI*Uniform(sfmt) );
    return mu + sigma*z;
}
// Log-normal分布
double rand_Lnormal(double mu, double sigma, sfmt_t *sfmt){
   double z= mu + sigma*sqrt(-2.0*log(Uniform(sfmt)))*sin(2.0*M_PI*Uniform(sfmt));//gauss random number
   return exp(z);
}
