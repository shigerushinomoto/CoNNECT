/*------------------------------------
記録をしやすくするための関数
変数
-  spikeを記録するfile pointer
- pspを記録するfile pointer
- Lvを記録するための変数
-------------------------------------*/
#ifndef LOG_H
#define LOG_H
#include<iostream>

class Log{
	int bin;
	double total_time, reject_time;
	double *Lv, *rate;
	double *tpre, *tpost, *Interval_pre, *Interval_post;
	FILE *fp_spike, *fp_g;
	std::string spikefile, Lvfile, fratefile, pspfile, delayfile; //file name
	int *spike_num;
	int N, N_e, N_i; // network size
private:
	virtual void init();
	virtual void _log(int step, Network* network);
public:
	Log() : N(0), N_e(0) {};
	virtual void fileopen(std::string spikefile, std::string Lvfile, std::string fratefile, std::string pspfile, std::string delayfile);
	/*file名を指定して、file pointerを開く*/
	virtual void open_g();
	virtual void set_size(int N, int N_e);
	virtual void set_time(double total_time, double reject_time);
	/*network sizeをsetする*/
	virtual void writeConnect(double** connection);
	virtual void writeDelay(int** delay_step);
	virtual void writeSpike(int index, double now);
	/*spikeを記録していく*/
	virtual void write_g(int step, Network* network);
	virtual void recordLv(int index, double now);
	/*spikeしたらLvを求めるために記録をしていく関数*/
	virtual void writeLv();
	/*simulationの最後にLvとfiring rateを記録していく関数*/
	virtual void write_wave(Network* network, std::string file);
	virtual void printLog(int step, Network* network);
	virtual ~Log();
};
#endif
