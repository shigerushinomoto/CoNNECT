#include<iostream>
#include<cmath>
#include<omp.h>
#include<SFMT.h>
#include<macro.h>
#include<random.h>
#include<threshold.h>
#include<conductance.h>
#include<neuron.h>
#include<network.h>
#include<log.h>
#include<simulation.h>
#include <stdlib.h>


int main(int argc, char* []){
	//========= parameter =========
	static const int seed = 200; // needed seed before making network
	const int N_seed = omp_get_max_threads();
	std::cout << "並列スレッド数は" << N_seed << std::endl;
	static const double total_time = 7300 * 1000; //msec
	static const double reject_time = 100 * 1000;

	static double alpha_e[] = {4.0};
	static double alpha_i[] = {2.2};
	static double amplitude_mean = 0.015;
	static double freqs[] = {7, 10, 20};
	static int N_fs[] = {100, 100, 100};
	static int N_wave = 3; // 全体に何種類の波をいれるか

	// バックグラウンドに関するループ
	for(int i=0; i<1; i++){
    std::cout << "=================== simulation START =============================" << std::endl;
		//========= データの保存先のディレクトリの作成 =========
		std::string dirname = "validation";//"ae" + std::to_string(alpha_e[i]).substr(0, 3) + "_ai" + std::to_string(alpha_i[i]).substr(0, 3);
		std::cout << dirname << "にデータを保存する" << std::endl;
		std::string command = "mkdir " + dirname;
		std::cout << command << std::endl;
		int flg = std::system(command.c_str());
		std::cout << "flg " << flg << std::endl;
		if(flg==1){
			std::cout << "すでに" << dirname << "は存在するようです.このままこのdirectoryを使用します." << std::endl;
		}

		//========= ファイル名の指定 =========
		const std::string spikefile = dirname + "/spike_time.txt";
		const std::string Lvfile = dirname + "/Lv_value.txt";
		const std::string fratefile = dirname + "/firing_rate.txt";
		const std::string pspfile = dirname + "/G_ij.csv";
		const std::string delayfile = dirname + "/delay.csv";
		const std::string wavefile = dirname + "/wave.txt";

		std::cout << "------------Preparing Simulation----------" << std::endl;
		std::cout << "background paramter: alpha_e " << alpha_e[i] << " alpha_i " << alpha_i[i] << std::endl;

		//========= neuronの数 ==========
		static const int N_e = 800;
		static const int N_i = 200;

		//======= 初期化 ========
		Simulation* simulation = new Simulation(N_e, N_i);
		simulation->init_random(seed);

		//=========  Logにファイル名を設定する =========
		simulation->init_log(spikefile, Lvfile, fratefile, pspfile, delayfile);

		//=========  neuronを生成する =========
		simulation->makeNeuron(alpha_e[i], alpha_i[i], amplitude_mean, N_wave, freqs, N_fs);

		//=========  結合を生成して, neuronをつなぐ =========
		simulation->set_network();

		simulation->write_wave(wavefile);

		std::cout << "------------- END: Preparing Simulation ------------------" << std::endl;
		//================ Running =============
		double t1,t2;
		t1 = omp_get_wtime();
		simulation->run(total_time, reject_time, N_seed);
		t2 = omp_get_wtime();
		std::cout << "Running time is " << t2 - t1 << " sec" << std::endl;
		delete simulation;
	}
	return 0;
}
