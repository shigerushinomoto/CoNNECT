/*---------------------------------------------
Neuronのネットワークを作る

できたNeuronと結合行列をsetで受け取る

ring ring_buffer:
	neuron iへのコンダクタンスのinputを時間遅れを含みながら記録する
-----------------------------------------------*/
#ifndef NETWORK_H
#define NETWORK_H
#include<neuron.h>
#include<connect.h>

class Network{
	const int N;
	int max_delay_step;
	int seed;
	int N_seed; //つまりはompのthread数
	double now;
	int now_step;
	double **ring_buffer_e, **ring_buffer_i;
public:
	sfmt_t *sfmt;
	Neuron *neurons;
	Connect *connect;
public:
	Network(int argN);
	/*pointerの初期化など*/
	virtual void set_neurons(Neuron *neuron, Connect *connect);
	/*別で定義したneuronとconnectを入れて、networkの作成をする*/
	virtual void init_network(int seed, int N_seed);
	/*時刻を0に設定して、乱数の初期化を行う。並列計算の設定もする*/
	virtual void set_spike_in_ringbuffer(sfmt_t *sfmt_out);
	virtual double get_now();
	/*現在時刻を得る*/
	virtual void update();
	/*1step分だけ時間発展させる*/
	virtual ~Network();
};

#endif
