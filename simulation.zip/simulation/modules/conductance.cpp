#include<iostream>
#include<cmath>
#include<omp.h>
#include<SFMT.h>
#include<macro.h>
#include<random.h>
#include<conductance.h>

const double Background :: dt_noise = sqrt(dt);

Conductance :: Conductance() {
}
void Conductance :: set_g0(double g0){
	if(g0<0){
		std::cout << "Value Error. your g0 < 0. g0 must be not less than 0." << std::endl;
		std::exit(1);
	}
	this->g = g0;
	this->g0 = g0;
}
void Conductance :: set_tau(double tau){
	if(tau<=0){
		std::cout << "Value Error. your tau <= 0. tau must be greater than 0." << std::endl;
		std::exit(1);
	}
	this->tau = tau;
}
void Conductance :: update(double input){
	// simulaion be faster when this below error check is erased
	if(input<0){
		std::cout << "Value Error. input must be not less than 0." << std::endl;
		std::exit(1);
	}
	// double dg;
	// dg = - (g-g0)/tau;
	// g += dg*dt + input;
	g += - dt * (g-g0)/tau + input;
	// negative value is not in exist.
	g = (g > 0) ? g : 0;
}
double Conductance :: get_conductance(){
	return g;
}
Conductance :: ~Conductance(){}

/*------Background class----------------------------------------------
----------------------------------------------------------------------*/
Background :: Background(){
	// empty
}
double Background :: makeNoise(sfmt_t *sfmt){
	return sigma*sqrt(2.0/tau)*rand_normal(0, 1, sfmt);
}
//-----------set----------------
void Background :: set_N_wave(int N_wave){
	if(N_wave<0){
		std::cout << "Value Error. N_wave must be not less than 0." << std::endl;
		std::exit(1);
	}
	this->N_wave = N_wave;
	if(N_wave==0){
		this->amplitude = NULL;
		this->omega = NULL;
		this->delta = NULL;
	}else{
		this->amplitude = new double[N_wave];
		this->omega = new double[N_wave];
		this->delta = new double[N_wave];
	}
}

void Background :: set_sigma(double sigma){
	this->sigma = sigma;
  if(sigma==0){
    std::cout << "background is Constant." << std::endl;
  } 
}

void Background :: set_wave(int i, double a, double w, double d){
	/*
	a: amplitude
	w: rad/ms
	d: rad
	*/
	if((i<0)|(i>=N_wave)){
		std::cout << "Value Error. wave index i must be between 0 and N_wave-1." << std::endl;
		std::exit(1);
	}
	if(w<0){
		std::cout << "Value Error. wave frequency is out of definition" << std::endl;
		std::exit(1);
	}
	if((d>2*M_PI)|(d<0)){
		std::cout << "Value Error. delta is out of definition" << std::endl;
		std::exit(1);
	}

	amplitude[i] = a;
	omega[i] = w;
	delta[i] = d;
}
//-----------get----------------
double Background :: get_dt_noise(){
	return dt_noise;
}
double Background :: get_sigma(){
	return sigma;
}
int Background :: get_N_wave(){
	return N_wave;
}
double Background :: get_amplitude(int i){
	if((i<0)|(i>=N_wave)){
		std::cout << "Value Error. wave index i must be between 0 and N_wave-1." << std::endl;
		std::exit(1);
	}
	return amplitude[i];
}
double Background :: get_omega(int i){
	if((i<0)|(i>=N_wave)){
		std::cout << "Value Error. wave index i must be between 0 and N_wave-1." << std::endl;
		std::exit(1);
	}
	return omega[i];
}
double Background :: get_delta(int i){
	if((i<0)|(i>=N_wave)){
		std::cout << "Value Error. wave index i must be between 0 and N_wave-1." << std::endl;
		std::exit(1);
	}
	return delta[i];
}
//------------------- update ----------------
void Background :: update(double now, sfmt_t *sfmt){
	/*
	backgroundのconductance を 1 step 分 時間発展させる
	計算式は別の資料を参照
	now : msec 単位
	*/
	double dwave = 0;
	for(int i=0; i<N_wave; i++){
		dwave += amplitude[i] * std::sin(omega[i]*now+delta[i]);
	}
	g += -dt*(g-g0)/tau + dwave*rand_normal(0, 1, sfmt)*dt_noise + makeNoise(sfmt)*dt_noise;
	// negative value is not in exist.
	g = (g > 0) ? g : 0;
}

Background :: ~Background(){
	if(N_wave>0){
		delete [] amplitude;
		delete [] omega;
		delete [] delta;
	}
}
