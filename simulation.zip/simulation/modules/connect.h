#ifndef CONNECT_H
#define CONNECT_H

/*----------------------------------
connect_t
あるneuronから出て行く結合をまとめた構造体
class Connectで使う
------------------------------------*/
typedef struct {
	// 出て行く結合の数. 隣接リストの長さなのでlengthという名前.
	int length;
	//出力先. neuronの番号
	int* adjacency;
	// 結合の大きさ. コンダクタンスG
	double* w;
	// 結合の遅れ. msではなくステップ数で入れておく.無駄な計算を減らすため.
	int* d_step;
} connect_t;

/*----------------------------------
neuron同士の結合を隣接リストにするためのクラス
------------------------------------*/
class Connect{
	int N;
	connect_t *connect;
public:
	Connect(){};
	//virtual void change_psp2G(int N, int N_e, double **connection, double e2e, double e2i, double i2e, double i2i);
	/*行列を隣接リストに変換する*/
	virtual void makeList(int N, double **connection, int **delay_step);

	/* fromはspikeしたneuronのindexを入れる*/
	virtual int getLength(int from);
	virtual int getIndex(int from, int k);
	virtual double getWeight(int from, int k);
	virtual int getDelay(int from, int k);
	virtual ~Connect();
};

#endif
