#include<iostream>
#include<cmath>
#include<SFMT.h>
#include<macro.h>
#include<random.h>
#include<threshold.h>

const int Threshold :: N = 2;
const double Threshold :: tau[] = {10, 200};

Threshold :: Threshold() : theta(0){
	init_pointer();
}
void Threshold :: init_pointer(){
	this->u = new double[N];
	this->alpha = new double[N];
	for(int i=0; i<N; i++){
		this->u[i] = 0;
	}
}
void Threshold :: set_omega(double omega){
	this->omega = omega;
}
void Threshold :: set_alpha(int i, double alpha_i){
	if((i<0)||(i>=N)){
		std::cout << "Value Error. i must be between " << std::endl;
		std::exit(1);
	}
	this->alpha[i] = alpha_i;
}
double Threshold :: get_theta(){
	theta = omega;
	for(int i=0; i<N; i++){
		theta += u[i];
	}
	return theta;
}
double Threshold :: get_omega(){
	return omega;
}
void Threshold :: increase_theta(){
	/* -----------------------------------
	if this neuron spike, then use this function
	-----------------------------------*/
	for(int i=0; i<N; i++){
		u[i] += alpha[i];
	}
}
void Threshold :: update(){
	/*------------------------------------
	時刻を進める
	-----------------------------------*/
	for(int i=0; i<N; i++){
		u[i] += -dt*u[i]/tau[i];
	}
}
