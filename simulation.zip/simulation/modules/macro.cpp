#include<iostream>
#include<macro.h>

double **d2array(int row, int column){
	/*
	matrix[i][j]で参照できる行列(ポインタ)をreturnする関数
	初期化はしていない。メモリを連続的に当てている。
	この操作ではなんどもポインタを使っているので注意。
	matrix[0]もポインタ。
	printf("%p\n",matrix[0]);とかで確認できる
	使い方：
	double **mat;
	mat = d2array(n ,m, l);
	*/
	double **matrix;
	int i;
	matrix = new double* [row];
	if(matrix == NULL){
		printf("d2arrayメモリが確保できません\n");
		std::exit(1);
	}
	matrix[0] = new double [row * column];
	if(matrix[0] == NULL){
		printf("d2array[0]メモリが確保できません\n");
		std::exit(1);
	}
	for(i=0; i<row; i++){
		matrix[i] = matrix[0] + i * column;
	}
	// init
	for(i=0; i<row; i++){
		for(int j=0; j<column; j++){
			matrix[i][j] = 0;
		}
	}
	return matrix;
}
/*２次元配列の解放*/
void d2free(double **array){
	delete [] array[0];
	array[0] = NULL;
	delete [] array;
	array = NULL;
}
int **i2array(int row, int column){
	/*
	matrix[i][j]で参照できる行列(ポインタ)をreturnする関数
	初期化はしていない。メモリを連続的に当てている。
	この操作ではなんどもポインタを使っているので注意。
	matrix[0]もポインタ。
	printf("%p\n",matrix[0]);とかで確認できる
	使い方：
	double **mat;
	mat = d2array(n ,m, l);
	*/
	int **matrix;
	int i;
	matrix = new int* [row];
	if(matrix == NULL){
		printf("d2arrayメモリが確保できません\n");
		std::exit(1);
	}
	matrix[0] = new int [row * column];
	if(matrix[0] == NULL){
		printf("d2array[0]メモリが確保できません\n");
		std::exit(1);
	}
	for(i=0; i<row; i++){
		matrix[i] = matrix[0] + i * column;
	}for(i=0; i<row; i++){
		for(int j=0; j<column; j++){
			matrix[i][j] = 0;
		}
	}
	return matrix;
}
/*２次元配列の解放*/
void i2free(int **array){
	delete [] array[0];
	array[0] = NULL;
	delete [] array;
	array = NULL;
}
