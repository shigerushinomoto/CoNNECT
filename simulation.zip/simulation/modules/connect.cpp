#include<iostream>
#include<cmath>
#include<omp.h>
#include<SFMT.h>
#include<macro.h>
#include<connect.h>


// void Connect :: change_psp2G(int N, int N_e, double **connection, double e2e, double e2i, double i2e, double i2i){
// 	/*受け取ったpspの変換をする
// 	中身をそのまま入れ替えるので注意*/
// 	std::string unit = " mS/cm^2";
// 	std::cout << "Changing PSP connection to Conductance connection" << std::endl;
// 	std::cout << "\tExc -> Exc: 1mv -> " << 1.0/e2e  << unit << std::endl;
// 	std::cout << "\tExc -> Inh: 1mv -> " << 1.0/e2i  << unit << std::endl;
// 	std::cout << "\tInh -> Exc: 1mv -> " << 1.0/i2e  << unit << std::endl;
// 	std::cout << "\tInh -> Inh: 1mv -> " << 1.0/i2i  << unit << std::endl;
//
// 	// 変換を行う
// 	int i, j;
// 	for (i=0; i<N; i++){
// 		for(j=0; j<N; j++){
// 			if(j<N_e){
// 				if(i<N_e){connection[i][j] = connection[i][j]/e2e;}
// 				else{connection[i][j] = connection[i][j]/e2i;}
// 			}else{
// 				if(i<N_e){connection[i][j] = connection[i][j]/i2e;}
// 				else{connection[i][j] = connection[i][j]/i2i;}
// 			}
// 		}
// 	}
// }
void Connect :: makeList(int N, double **connection,  int **delay_step){
	/*--------------------------------------------------------------
	コンダクタンスの結合とsynaptic delayを隣接リストに変化する.
	neuron j-th に入ってくる結合を求める.
	手順:
	1. 長さを調べて配列を獲得
	2. jで興奮抑制が決まるので、あとはただ値を格納すれば良いjからiへの結合. 結合はjからiへの形になっている
	--------------------------------------------------------------*/
	this->N = N;
	//struct connect_t
	connect = new connect_t[N];

	std::cout << "Starting Making adjacency list" << std::endl;
	int i, j, k, length;
	for(j=0; j<N; j++){

		// 長さを計算
		length = 0;
		for(i=0; i<N; i++){
			if(connection[i][j] > 0) length += 1;
		}

		// neuron jからの結合分(length)の配列を確保する
		connect[j].length = length;
		connect[j].adjacency = new int[length];//(int *)malloc(sizeof(int)*length);
		connect[j].w = new double [length]; //(double*)malloc(sizeof(double)*length);
		connect[j].d_step = new int [length];
		if(connect[j].adjacency==NULL||connect[j].w==NULL){
			puts("Connect class Error. Out of memmory\n");
			std::exit(1);
		}

		// 確保した配列に結合の値を入れていく
		k = 0;
		for(i=0; i<N; i++){
			// 結合があるところだけ残す
			if (connection[i][j] > 0){
				// 結合先のneuron index
				connect[j].adjacency[k] = i;
				// neuron iへの結合の大きさ
				connect[j].w[k] = connection[i][j];
				// neuron iまでのdelay
				connect[j].d_step[k] = delay_step[i][j];
				// 次の結合へ
				k += 1;
			}
		}
	}
	std::cout << "End: Made adjacency list" << std::endl;
}

int Connect :: getLength(int from){
	/*
	neuron from からの結合の数を取得
	*/
	return connect[from].length;
}

int Connect :: getIndex(int from, int k){
	/*
	neuron fromからk番目の結合のneuron indexを取得
	*/
	return connect[from].adjacency[k];
}

double Connect :: getWeight(int from, int k){
	return connect[from].w[k];
}

int Connect :: getDelay(int from, int k){
	return connect[from].d_step[k];
}

Connect :: ~Connect(){
	for(int i=0; i<N; i++){
		delete [] connect[i].adjacency;
		delete [] connect[i].w;
		delete [] connect[i].d_step;
	}
	delete [] connect;
}
