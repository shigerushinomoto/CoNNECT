/*----------------------------------------
基本的にはこれをいじれば良い.こいつがmain file的な役割をする
機能
- simualtionするrun
- 記録するlogなと
------------------------------------------*/

#ifndef SIMULATION_H
#define SIMULATION_H
#include<network.h>
#include<log.h>

class Simulation{
	//Neuron *neurons;
	const int N_e, N_i, N;
	sfmt_t *sfmt;
	Network *network;
	Neuron *neurons;
	Log *log;
	int seed;
	//int **delay_step;
public:
	Simulation(int argN_e, int argN_i);
	virtual void init_random(int seed);
	virtual void makeNeuron(double alpha_e, double alpha_i, double amplitude_mean, int N_wave, double* freqs, int* N_fs);
	/* neuronの初期設定をする。これとは別にコンダクタンス等の初期化もすることを忘れない
	alpha_e, alpha_i: バックグラウンドの大きさを決定する
	amplitude_mean: この値をもとに振動の大きさを決定する
	N_wave: 振動の種類の数
	freqs: 振動数 Hzで入れる.
	N_fs: それぞれの振動数の数を指定。全neuronを超えないように
	*/
	virtual double** makeConnection();
	/*コンダクタンスの結合を作る*/
	virtual int** makeDelay(double** connection);
	/*コンダクタンスの結合を元にsynaptic delayを入れる*/
	virtual void init_log(std::string spikefile, std::string Lvfile, std::string fratefile, std::string pspfile, std::string);
	virtual void set_network();
	virtual void write_wave(std::string wavefile);
	virtual void run(double total_time, double reject_time, int N_seed);
	virtual ~Simulation();
};

#endif
